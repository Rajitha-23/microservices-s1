package com.foodDelivery.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.foodDelivery.proxy.AdminServiceProxy;

import java.util.Map;

@RestController
@RequestMapping("/admin")
public class AdminClientController {

    @Autowired
    private AdminServiceProxy adminServiceProxy;

    private Logger log = LoggerFactory.getLogger(AdminClientController.class);

    @SuppressWarnings("rawtypes")
    @PostMapping("/{username}")
    public ResponseEntity<Boolean> verifyAdminLogin(
            @RequestBody Map<String, String> loginData,
            @PathVariable(name = "username") String username) {

        log.debug("Verifying login for admin with username: " + username);

        // Call the AdminServiceProxy to verify admin login
        boolean loginResult = adminServiceProxy.verifyAdminLogin(loginData, username);

        if (loginResult) {
            log.debug("Admin with username " + username + " successfully logged in.");
            return ResponseEntity.ok(true);
        } else {
            log.debug("Login failed for admin with username: " + username);
            return ResponseEntity.ok(false);
        }
    }
}
