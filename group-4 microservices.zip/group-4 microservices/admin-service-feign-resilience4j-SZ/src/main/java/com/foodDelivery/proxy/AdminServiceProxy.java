package com.foodDelivery.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;



import java.util.Map;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "admin-service")
public interface AdminServiceProxy {

    @Retry(name = "admin-service")
    @CircuitBreaker(name = "admin-service", fallbackMethod = "fallbackMethodVerifyAdminLogin")
    @PostMapping("/admin/{username}")
    public boolean verifyAdminLogin(@RequestBody Map<String, String> loginData, @PathVariable(name = "username") String username);

    default boolean fallbackMethodVerifyAdminLogin(@RequestBody Map<String, String> loginData, String username, Throwable cause) {
        System.out.println("Exception raised while verifying admin login: " + cause.getMessage());
        // You can return a default boolean or perform custom error handling here.
        return false; // Return false as a fallback.
    }
}
