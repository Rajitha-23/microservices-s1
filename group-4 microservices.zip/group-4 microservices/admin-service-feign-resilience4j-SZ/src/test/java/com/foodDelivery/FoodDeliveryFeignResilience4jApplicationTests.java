package com.foodDelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryFeignResilience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
