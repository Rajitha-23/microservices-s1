package com.foodDelivery.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.foodDelivery.entity.Product;

import java.util.List;
import java.util.Map;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "product-service")
public interface ProductServiceProxy {

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodAddProduct")
    @PostMapping("/products")
    public Product addProduct(@RequestBody Product product);

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodUpdateProduct")
    @PutMapping("/products/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product product);

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodDeleteProduct")
    @DeleteMapping("/products/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id);

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetProductById")
    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable long id);

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetAllProducts")
    @GetMapping("/products")
    public List<Product> getAllProducts();

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodSearchProducts")
    @GetMapping("/products/search/{keyword}")
    public List<Product> searchProducts(@PathVariable String keyword);

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetChinese")
    @GetMapping("/api/products/chinese")
    public List<Product> getChinese();

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetIndian")
    @GetMapping("/api/products/indian")
    public List<Product> getIndian();

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetMexican")
    @GetMapping("/products/mexican")
    public List<Product> getMexican();

    @Retry(name = "product-service")
    @CircuitBreaker(name = "product-service", fallbackMethod = "fallbackMethodGetItalian")
    @GetMapping("/products/italian")
    public List<Product> getItalian();

    default Product fallbackMethodAddProduct(@RequestBody Product product, Throwable cause) {
        System.out.println("Exception raised while adding a product: " + cause.getMessage());
        // You can return a default Product object or perform custom error handling here.
        return new Product(); // Return an empty Product as a fallback.
    }

    default ResponseEntity<Product> fallbackMethodUpdateProduct(Long id, Product product, Throwable cause) {
        System.out.println("Exception raised while updating a product: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    default ResponseEntity<Map<String, Boolean>> fallbackMethodDeleteProduct(Long id, Throwable cause) {
        System.out.println("Exception raised while deleting a product: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    default ResponseEntity<Product> fallbackMethodGetProductById(long id, Throwable cause) {
        System.out.println("Exception raised while getting a product by ID: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    default List<Product> fallbackMethodGetAllProducts(Throwable cause) {
        System.out.println("Exception raised while getting all products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Product> fallbackMethodSearchProducts(String keyword, Throwable cause) {
        System.out.println("Exception raised while searching for products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Product> fallbackMethodGetChinese(Throwable cause) {
        System.out.println("Exception raised while getting Chinese cuisine products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Product> fallbackMethodGetIndian(Throwable cause) {
        System.out.println("Exception raised while getting Indian cuisine products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Product> fallbackMethodGetMexican(Throwable cause) {
        System.out.println("Exception raised while getting Mexican cuisine products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Product> fallbackMethodGetItalian(Throwable cause) {
        System.out.println("Exception raised while getting Italian cuisine products: " + cause.getMessage());
        // You can return a default list of Product objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }
}
