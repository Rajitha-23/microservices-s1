package com.foodDelivery.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.foodDelivery.entity.Product;
import com.foodDelivery.proxy.ProductServiceProxy;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductServiceProxy productServiceProxy;

    private Logger log = LoggerFactory.getLogger(ProductController.class);

    @GetMapping
    public List<Product> getAllProducts() {
        log.debug("Retrieving all products");
        List<Product> products = productServiceProxy.getAllProducts();
        log.debug("Retrieved " + products.size() + " products");
        return products;
    }

    @PostMapping("/add")
    public Product addProduct(@RequestBody Product product) {
        log.debug("Adding a new product: " + product.toString());
        Product addedProduct = productServiceProxy.addProduct(product);
        log.debug("Added product: " + addedProduct.toString());
        return addedProduct;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
        log.debug("Updating product with id: " + id);
        ResponseEntity<Product> response = productServiceProxy.updateProduct(id, productDetails);
        log.debug("Updated product: " + response.getBody().toString());
        return response;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id) {
        log.debug("Deleting product with id: " + id);
        ResponseEntity<Map<String, Boolean>> response = productServiceProxy.deleteProduct(id);
        log.debug("Deleted product: " + id);
        return response;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable long id) {
        log.debug("Retrieving product with id: " + id);
        ResponseEntity<Product> response = productServiceProxy.getProductById(id);
        log.debug("Retrieved product: " + response.getBody().toString());
        return response;
    }

    @GetMapping("/search/{keyword}")
    public List<Product> getSearchProducts(@PathVariable String keyword) {
        log.debug("Searching products with keyword: " + keyword);
        List<Product> searchResults = productServiceProxy.searchProducts(keyword);
        log.debug("Found " + searchResults.size() + " products matching the keyword");
        return searchResults;
    }

    @GetMapping("/chinese")
    public List<Product> getChinese() {
        log.debug("Retrieving Chinese cuisine products");
        List<Product> chineseProducts = productServiceProxy.getChinese();
        log.debug("Retrieved " + chineseProducts.size() + " Chinese cuisine products");
        return chineseProducts;
    }

    @GetMapping("/indian")
    public List<Product> getIndian() {
        log.debug("Retrieving Indian cuisine products");
        List<Product> indianProducts = productServiceProxy.getIndian();
        log.debug("Retrieved " + indianProducts.size() + " Indian cuisine products");
        return indianProducts;
    }

    @GetMapping("/mexican")
    public List<Product> getMexican() {
        log.debug("Retrieving Mexican cuisine products");
        List<Product> mexicanProducts = productServiceProxy.getMexican();
        log.debug("Retrieved " + mexicanProducts.size() + " Mexican cuisine products");
        return mexicanProducts;
    }

    @GetMapping("/italian")
    public List<Product> getItalian() {
        log.debug("Retrieving Italian cuisine products");
        List<Product> italianProducts = productServiceProxy.getItalian();
        log.debug("Retrieved " + italianProducts.size() + " Italian cuisine products");
        return italianProducts;
    }
}
