package com.cartService.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cartService.entity.Cart;
import com.cartService.service.CartService;

@RestController
public class CartController {

    @Autowired
    private CartService cartService;

    private Logger log = LoggerFactory.getLogger(CartController.class);


    @PostMapping("/carts")
    public Cart addToCart(@RequestBody Cart cart, HttpSession session) {
        return cartService.addToCart(cart, session);
    }

    @GetMapping("/carts")
    public List<Cart> getCartItems() {
        log.debug("Retrieving CartList:");
        return cartService.getCartItems();
    }

    @PutMapping("/carts/add/{id}")
    public ResponseEntity<Cart> addByOne(@PathVariable("id") long id, @RequestBody Cart cart) {
        Cart updatedCart = cartService.addByOne(id, cart);
        if (updatedCart != null) {
            return ResponseEntity.ok(updatedCart);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/carts/minus/{id}")
    public ResponseEntity<Cart> lessByOne(@PathVariable("id") long id, @RequestBody Cart cart) {
        Cart updatedCart = cartService.lessByOne(id, cart);
        if (updatedCart != null) {
            return ResponseEntity.ok(updatedCart);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/carts/{id}")
    public ResponseEntity<?> deleteCart(@PathVariable("id") Long id) {
        cartService.deleteCart(id);
        log.debug("DEleting by id:" + id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/carts")
    public void deleteAllCart() {
        log.debug("deleting all Cart Items:");
        cartService.deleteAllCart();
    }
}
