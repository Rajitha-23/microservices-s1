package com.cartService.service;


import com.cartService.entity.Cart;
import com.cartService.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Override
    public Cart addToCart(Cart cart, HttpSession session) {
        float grandTotal = 0;
        if (session.getAttribute("grandTotal") == null) {
            grandTotal = 0;
        } else {
            grandTotal = (float) session.getAttribute("grandTotal");
        }
        List<Cart> cartList = cartRepository.findAll();
        for (Cart temp : cartList) {
            if (temp.getProduct().getId() == cart.getProduct().getId()) {
                int tempQuantity = 1 + temp.getQuantity();
                grandTotal = grandTotal + temp.getPrice();
                session.setAttribute("grandTotal", grandTotal);
                temp.setQuantity(tempQuantity);
                temp.setPrice((temp.getProduct().getPrice() * tempQuantity));
                return cartRepository.save(temp);
            }
        }
        int min = 100;
        int max = 999;
        int b = (int) (Math.random() * (max - min + 1) + min);
        cart.setId(b);
        cart.setQuantity(1);
        cart.setPrice(cart.getProduct().getPrice());
        grandTotal = grandTotal + cart.getProduct().getPrice();
        session.setAttribute("grandTotal", grandTotal);
        return cartRepository.save(cart);
    }

    @Override
    public List<Cart> getCartItems() {
        return cartRepository.findAll();
    }

    @Override
    public Cart addByOne(long id, Cart cart) {
        Cart existingCart = cartRepository.findById(id)
                .orElse(null);
        if (existingCart != null) {
            int quantity = existingCart.getQuantity() + 1;
            existingCart.setQuantity(quantity);
            existingCart.setPrice(existingCart.getProduct().getPrice() * quantity);
            return cartRepository.save(existingCart);
        }
        return null; 
    }

    @Override
    public Cart lessByOne(long id, Cart cart) {
        Cart existingCart = cartRepository.findById(id)
                .orElse(null);
        if (existingCart != null) {
            int quantity = existingCart.getQuantity() - 1;
            if (quantity != 0) {
                existingCart.setQuantity(quantity);
                existingCart.setPrice(existingCart.getProduct().getPrice() * quantity);
                return cartRepository.save(existingCart);
            } else {
                cartRepository.deleteById(id);
                return null; 
            }
        }
        return null;
    }

    @Override
    public void deleteCart(Long id) {
        cartRepository.deleteById(id);
    }

    @Override
    public void deleteAllCart() {
        cartRepository.deleteAll();
    }
}