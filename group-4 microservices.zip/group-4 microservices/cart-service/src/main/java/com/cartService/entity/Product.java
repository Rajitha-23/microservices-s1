package com.cartService.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Product {
    @Id
     private long id;
     private String name;
     private String des;
     private String category;
     private float actualPrice;
     private float discount;
     private float price;
     private String avail;
     private String imagepath;	
}

