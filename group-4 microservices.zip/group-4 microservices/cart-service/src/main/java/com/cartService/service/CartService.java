package com.cartService.service;


import com.cartService.entity.Cart;
import javax.servlet.http.HttpSession;
import java.util.List;

public interface CartService {
    Cart addToCart(Cart cart,HttpSession session );
    List<Cart> getCartItems();
    Cart addByOne(long id, Cart cart);
    Cart lessByOne(long id, Cart cart);
    void deleteCart(Long id);
    void deleteAllCart();
}