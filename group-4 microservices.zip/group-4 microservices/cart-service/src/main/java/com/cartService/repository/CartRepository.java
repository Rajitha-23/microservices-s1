package com.cartService.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.cartService.entity.Cart;



public interface CartRepository extends JpaRepository<Cart, Long> {
  
}
