package com.service;


import com.entity.Product;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface IProductService {

      List<Product> getAllProducts();

    Product addProduct(Product product);

     ResponseEntity<Product> updateProduct(Long id, Product productDetails);

    ResponseEntity<Map<String, Boolean>> deleteProduct(Long id);

    ResponseEntity<Product> getProductById(long id);

    List<Product> getSearchProducts(String keyword);

    List<Product> getChinese();

    List<Product> getIndian();

    List<Product> getMexican();

    List<Product> getItalian();
}
