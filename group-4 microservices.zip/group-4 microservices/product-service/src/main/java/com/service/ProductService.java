package com.service;

import com.entity.Product;
import com.exception.ResourceNotFoundException;
import com.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductService implements IProductService {

    @Autowired
    private ProductRepository productRepository;

    

	public List<Product> getAllProducts() {
		List<Product> prodList=productRepository.findIfAvail();
		if(prodList.isEmpty()) {
			System.out.println("No Items Available. We are Closed.");}
		return prodList;
	}
    

  /*  public void addProdIfEmpty(Product product) {
       
        int min = 10000;
        int max = 99999;
        int b = (int) (Math.random() * (max - min + 1) + min);
        product.setId(b);
        float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
        float price = product.getActualPrice() - temp;
        product.setPrice(price);
        productRepository.save(product);
    } */

    public Product addProduct(Product product) {
       
        int min = 10000;
        int max = 99999;
        int b = (int) (Math.random() * (max - min + 1) + min);
        product.setId(b);
        float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
        float price = product.getActualPrice() - temp;
        product.setPrice(price);
        return productRepository.save(product);
    }

    public ResponseEntity<Product> updateProduct(Long id, Product productDetails) {
       
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product Not Found with " + id));
        product.setName(productDetails.getName());
        product.setDes(productDetails.getDes());
        product.setCategory(productDetails.getCategory());
        product.setImagepath(productDetails.getImagepath());
        product.setActualPrice(productDetails.getActualPrice());
        product.setDiscount(productDetails.getDiscount());
        product.setAvail(productDetails.getAvail());
        float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
        float price = product.getActualPrice() - temp;
        product.setPrice(price);

        Product updatedProd = productRepository.save(product);
        return ResponseEntity.ok(updatedProd);
    }

    public ResponseEntity<Map<String, Boolean>> deleteProduct(Long id) {
      
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product Not Found with " + id));
        productRepository.delete(product);
        Map<String, Boolean> map = new HashMap<>();
        map.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(map);
    }
    
    public ResponseEntity<Product> getProductById(long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product Not Found with " + id));
        return ResponseEntity.ok(product);
    }

    public List<Product> getSearchProducts(String keyword) {
        return productRepository.homeSearch(keyword);
    }

    public List<Product> getChinese() {
        return productRepository.getChinese();
    }

    public List<Product> getIndian() {
        return productRepository.getIndian();
    }

    public List<Product> getMexican() {
        return productRepository.getMexican();
    }

    public List<Product> getItalian() {
        return productRepository.getItalian();
    }

    
}

