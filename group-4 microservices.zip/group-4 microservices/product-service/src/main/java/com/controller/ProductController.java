package com.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.entity.Product;
import com.service.ProductService;


//@CrossOrigin(origins = "http://localhost:4200")

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;
    
    private Logger log = LoggerFactory.getLogger(ProductController.class);
    
    @GetMapping
    public List<Product> getAllProducts() {
        log.debug("Fetching all products");
        List<Product> products = productService.getAllProducts();
        log.debug("Fetched {} products", products.size()); // Log the number of products retrieved
        return products;
    }

    @PostMapping("/add")
    public Product addProduct(@RequestBody Product product) {
    	log.debug("In AddProduct: {}", product);
        return productService.addProduct(product);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
    	log.debug("Request received to update product with ID: " + id);
    	return productService.updateProduct(id, productDetails);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id) {
    	log.debug("Request received to delete product with ID: " + id);
    	return productService.deleteProduct(id);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable long id) {
        log.debug("Request received to retrieve product with ID: " + id);
    	return productService.getProductById(id);
    }

    @GetMapping("/search/{keyword}")
    public List<Product> getSearchProducts(@PathVariable String keyword) {
    	 log.debug("Request received to search products with keyword: " + keyword);
        return productService.getSearchProducts(keyword);
    }

    @GetMapping("/chinese")
    public List<Product> getChinese() {
    	  log.debug("Request received to retrieve Chinese products.");
        return productService.getChinese();
    }

    @GetMapping("/indian")
    public List<Product> getIndian() {
    	log.debug("Request received to retrieve Indian products.");
        return productService.getIndian();
    }

    @GetMapping("/mexican")
    public List<Product> getMexican() {
    	log.debug("Request received to retrieve Mexican products.");
        return productService.getMexican();
    }

    @GetMapping("/italian")
    public List<Product> getItalian() {
    	log.debug("Request received to retrieve Italian products.");
        return productService.getItalian();
    }
  }