package com.foodDelivery.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.foodDelivery.entity.Admin;
import com.foodDelivery.repository.AdminRepository;


@RestController
public class AdminController {
	
	@Autowired
	private AdminRepository adminRepository;
	
	   private Logger log = LoggerFactory.getLogger(AdminController.class);

	
	@SuppressWarnings("rawtypes")
	@PostMapping("/admin/{username}")
	public boolean verifyAdminLogin(@RequestBody Map loginData, @PathVariable(name = "username") String username, HttpSession session) {
		String lusername=(String) loginData.get("username");
		String lpassword=(String) loginData.get("password");
		log.debug("Verifying login for admin with username: " + lusername);

		Admin admin = adminRepository.findByusername(username);
		if(admin!=null && admin.getUsername().equals(lusername) && admin.getPassword().equals(lpassword)) {
			session.setAttribute("adminUsername", lusername);
			  log.debug("Admin with username " + lusername + " successfully logged in.");

			return true;
		}else {
			log.debug("Login failed for admin with username: " + lusername);
            return false;
		}
	}
}
