package com.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.model.Customer;
import com.service.CustomerService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    @Autowired
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    private Logger log = LoggerFactory.getLogger(CustomerController.class);

    @PostMapping
    public Customer addCustomer(@RequestBody Customer customer) {
        log.debug("Adding a new customer: " + customer.toString());
        Customer addedCustomer = customerService.addCustomer(customer);
        log.debug("Added customer: " + addedCustomer.toString());
        return addedCustomer;
    }

    @PostMapping("/login")
    public ResponseEntity<Boolean> verifyLogin(@RequestBody Map<String, String> loginData) {
        String email = loginData.get("email");
        log.debug("Verifying login for customer with email: " + email);
        String password = loginData.get("password");
        boolean loginResult = customerService.verifyLogin(email, password);
        log.debug("Login verification result: " + loginResult);
        return ResponseEntity.ok(loginResult);
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        log.debug("Retrieving all customers");
        List<Customer> customers = customerService.getAllCustomers();
        log.debug("Retrieved " + customers.size() + " customers");
        return customers;
    }

    @GetMapping("/search/{keyword}")
    public List<Customer> searchCustomer(@PathVariable String keyword) {
        log.debug("Searching customers with keyword: " + keyword);
        List<Customer> searchResults = customerService.searchCustomer(keyword);
        log.debug("Found " + searchResults.size() + " customers matching the keyword");
        return searchResults;
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable String email) {
        log.debug("Deleting customer with email: " + email);
        customerService.deleteCustomer(email);
        log.debug("Customer with email " + email + " deleted successfully");
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{email}")
    public Customer getCustomer(@PathVariable String email) {
        log.debug("Retrieving customer with email: " + email);
        Customer customer = customerService.getCustomerByEmail(email);
        log.debug("Retrieved customer: " + customer.toString());
        return customer;
    }
}
