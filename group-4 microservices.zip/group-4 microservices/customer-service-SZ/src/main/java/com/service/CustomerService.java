package com.service;

import java.util.List;

import com.model.Customer;

public interface CustomerService {
    Customer addCustomer(Customer customer);

    boolean verifyLogin(String email, String password);

    List<Customer> getAllCustomers();

    List<Customer> searchCustomer(String keyword);

    void deleteCustomer(String email);

    Customer getCustomerByEmail(String email);
}

