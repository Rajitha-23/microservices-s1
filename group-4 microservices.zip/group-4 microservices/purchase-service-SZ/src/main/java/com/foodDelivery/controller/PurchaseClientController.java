package com.foodDelivery.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.foodDelivery.entity.Purchase;
import com.foodDelivery.proxy.PurchaseServiceProxy;

@RestController
public class PurchaseClientController {

    @Autowired
    private PurchaseServiceProxy purchaseServiceProxy;
    
    private Logger log = LoggerFactory.getLogger(PurchaseClientController.class);

    @GetMapping("/purchase/byEmail/{email}")
    public List<Purchase> customerOrders(@PathVariable String email) {
    	  log.debug("Request received to retrieve customer orders for email: " + email);
        return purchaseServiceProxy.customerOrders(email);
    }

    @GetMapping("/purchase")
    public List<Purchase> getAllPurchase() {
    	log.debug("Request received to retrieve all purchases.");
        return purchaseServiceProxy.getAllPurchase();
    }

    @DeleteMapping("/purchase/{id}")
    public ResponseEntity<Map<String, Boolean>> deletePurchase(@PathVariable Long id) {
    	log.debug("Request received to delete purchase with ID: " + id);
        return purchaseServiceProxy.deletePurchase(id);
    }

    @PostMapping("/purchase")
    public ResponseEntity<Map<String, Boolean>> buyProducts(@RequestBody Map buyProdMap) {
    	log.debug("Request received to buy products.");
        return purchaseServiceProxy.buyProducts(buyProdMap);
    }
}
