package com.foodDelivery.proxy;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.foodDelivery.entity.Purchase;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "purchase-service")
public interface PurchaseServiceProxy {
	
	 @Retry(name = "purchase-service")
	 @CircuitBreaker(name = "purchase-service", fallbackMethod = "fallbackMethodCustomOrders")
	@GetMapping("/purchase/byEmail/{email}")
	public List<Purchase> customerOrders(@PathVariable String email);
	
	 @Retry(name = "purchase-service")
	 @CircuitBreaker(name = "purchase-service", fallbackMethod = "fallbackMethodGetAllPurchase")
	@GetMapping("/purchase")
	public List<Purchase> getAllPurchase();
	
	 @Retry(name = "purchase-service")
	 @CircuitBreaker(name = "purchase-service", fallbackMethod = "fallbackMethodDeletePurchase")
	@DeleteMapping("/purchase/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePurchase(@PathVariable Long id);
	
	 @Retry(name = "purchase-service")
	 @CircuitBreaker(name = "purchase-service", fallbackMethod = "fallbackMethodBuyProducts")
	@SuppressWarnings("rawtypes")
	@PostMapping("/purchase")
	public ResponseEntity<Map<String, Boolean>> buyProducts(@RequestBody Map buyProdMap);
	 

	    // Fallback method for customerOrders
	    default List<Purchase> fallbackMethodCustomOrders(@PathVariable String email, Throwable ex) {
	        // Implement your fallback logic here, e.g., return an empty list
	        System.out.println("Fallback method called for customerOrders due to: " + ex.getMessage());
	        return List.of();
	    }

	    // Fallback method for getAllPurchase
	    default List<Purchase> fallbackMethodGetAllPurchase(Throwable ex) {
	        // Implement your fallback logic here, e.g., return an empty list
	        System.out.println("Fallback method called for getAllPurchase due to: " + ex.getMessage());
	        return List.of();
	    }

	    // Fallback method for deletePurchase
	    default ResponseEntity<Map<String, Boolean>> fallbackMethodDeletePurchase(Long id, Throwable ex) {
	        // Implement your fallback logic here, e.g., return a ResponseEntity with an error message
	        System.out.println("Fallback method called for deletePurchase due to: " + ex.getMessage());
	        Map<String, Boolean> errorResponse = Map.of("error", true);
	        return ResponseEntity.status(500).body(errorResponse);
	    }

	    // Fallback method for buyProducts
	    @SuppressWarnings("rawtypes")
	    default ResponseEntity<Map<String, Boolean>> fallbackMethodBuyProducts(Map buyProdMap, Throwable ex) {
	        // Implement your fallback logic here, e.g., return a ResponseEntity with an error message
	        System.out.println("Fallback method called for buyProducts due to: " + ex.getMessage());
	        Map<String, Boolean> errorResponse = Map.of("error", true);
	        return ResponseEntity.status(500).body(errorResponse);
	    }

}


