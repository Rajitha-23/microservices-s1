package com.food.delivery.purchaseservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurchaseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
