package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exception.ResourceNotFoundException;

import com.entity.Cart;
import com.entity.Customer;
import com.entity.Purchase;
import com.repository.CartRepository;
import com.repository.CustomerRepository;
import com.repository.PurchaseRepository;

@RestController
public class PurchaseController {
	
	@Autowired
	private PurchaseRepository purchaseRepository;
	
	@Autowired
	private CartRepository cartRepository; 
	
	@Autowired
	private CustomerRepository customerRepository;
	
	 private Logger log = LoggerFactory.getLogger(PurchaseController.class);
	
	@GetMapping("/purchase/byEmail/{email}")
	public List<Purchase> customerOrders(@PathVariable String email) {
	    log.debug("Request received to retrieve customer orders for email: " + email);
		return purchaseRepository.getByEmail(email);
	}
	
	@GetMapping("/purchase")
	public List<Purchase> getAllPurchase(){
		log.debug("Request received to retrieve all purchases.");
		return purchaseRepository.findAllByOrderByTransactionidAsc();
	}
	
	@DeleteMapping("/purchase/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePurchase(@PathVariable Long id) {
		Purchase purchase = purchaseRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Purchase Id not found with "+id));
		purchaseRepository.delete(purchase);
		Map<String, Boolean> map = new HashMap<>();
		map.put("deleted", Boolean.TRUE);
		log.debug("Purchase with ID " + id + " has been deleted.");
		return ResponseEntity.ok(map);
	}
	
	@GetMapping("/purchase/search/{keyword}")
	public List<Purchase> searchPurchase(@PathVariable String keyword){
		 log.debug("Request received to search purchases with keyword: " + keyword);
		return purchaseRepository.searchPurchase(keyword);
	}
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/purchase")
	public ResponseEntity<Map<String, Boolean>> buyProducts(@RequestBody Map buyProdMap){
		List<Cart> cartList = cartRepository.findAll();
		Purchase purchase = new Purchase();
		String cust_email=(String)buyProdMap.get("email");
		Customer customer = customerRepository.findByEmail(cust_email);
		String transId = (String)buyProdMap.get("transactionId");
		for(Cart cl:cartList) {
			long min=100000;long max=999999;long b = (long)(Math.random()*(max-min+1)+min);
			purchase.setId(b);
			purchase.setCustomer(customer);
			String name = cl.getProduct().getName();
			purchase.setProductname(name);
			purchase.setQuantity(cl.getQuantity());
			purchase.setTotalcost(cl.getPrice());
			purchase.setTransactionid(transId);
			purchaseRepository.save(purchase);
		}
		Map<String, Boolean> map = new HashMap<>();
		map.put("created",Boolean.TRUE);
		log.debug("Products have been purchased.");
		return ResponseEntity.ok(map);
	}
}

