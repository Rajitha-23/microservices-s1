package com.foodDelivery.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.foodDelivery.entity.Cart;
import com.foodDelivery.proxy.CartServiceProxy;

import java.util.List;

@RestController
@RequestMapping("/carts")
public class CartClientController {

    @Autowired
    private CartServiceProxy cartServiceProxy;

    private Logger log = LoggerFactory.getLogger(CartClientController.class);

    @PostMapping
    public Cart addToCart(@RequestBody Cart cart) {
        log.debug("Adding to cart: " + cart.toString());
        Cart addedToCart = cartServiceProxy.addToCart(cart);
        log.debug("Added to cart: " + addedToCart.toString());
        return addedToCart;
    }

    @GetMapping
    public List<Cart> getCartItems() {
        log.debug("Retrieving cart items");
        List<Cart> cartItems = cartServiceProxy.getCartItems();
        log.debug("Retrieved " + cartItems.size() + " cart items");
        return cartItems;
    }

    @PutMapping("/add/{id}")
    public ResponseEntity<Cart> addByOne(@PathVariable("id") long id, @RequestBody Cart cart) {
        log.debug("Adding one to cart item with id: " + id);
        ResponseEntity<Cart> response = cartServiceProxy.addByOne(id, cart);
        log.debug("Updated cart item: " + response.getBody());
        return response;
    }

    @PutMapping("/minus/{id}")
    public ResponseEntity<Cart> lessByOne(@PathVariable("id") long id, @RequestBody Cart cart) {
        log.debug("Reducing quantity by one for cart item with id: " + id);
        ResponseEntity<Cart> response = cartServiceProxy.lessByOne(id, cart);
        log.debug("Updated cart item: " + response.getBody());
        return response;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCart(@PathVariable("id") Long id) {
        log.debug("Deleting cart item with id: " + id);
        cartServiceProxy.deleteCart(id);
        log.debug("Cart item with id " + id + " deleted successfully");
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public void deleteAllCart() {
        log.debug("Deleting all cart items");
        cartServiceProxy.deleteAllCart();
    }
}
