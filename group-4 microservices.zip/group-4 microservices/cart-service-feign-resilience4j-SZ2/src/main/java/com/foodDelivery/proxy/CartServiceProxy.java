package com.foodDelivery.proxy;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.foodDelivery.entity.Cart;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "cart-service")
public interface CartServiceProxy {

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service")
    @PostMapping("/carts")
    public Cart addToCart(@RequestBody Cart cart);

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service", fallbackMethod = "fallbackMethodGetCartItems")
    @GetMapping("/carts")
    public List<Cart> getCartItems();

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service", fallbackMethod = "fallbackMethodAddByOne")
    @PutMapping("/carts/add/{id}")
    public ResponseEntity<Cart> addByOne(@PathVariable("id") long id, @RequestBody Cart cart);

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service", fallbackMethod = "fallbackMethodLessByOne")
    @PutMapping("/carts/minus/{id}")
    public ResponseEntity<Cart> lessByOne(@PathVariable("id") long id, @RequestBody Cart cart);

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service", fallbackMethod = "fallbackMethodDeleteCart")
    @DeleteMapping("/carts/{id}")
    public ResponseEntity<?> deleteCart(@PathVariable("id") Long id);

    @Retry(name = "cart-service")
    @CircuitBreaker(name = "cart-service", fallbackMethod = "fallbackMethodDeleteAllCart")
    @DeleteMapping("/carts")
    public void deleteAllCart();

//    default Cart fallbackMethodAddToCart(@RequestBody Cart cart, HttpSession session, Throwable cause) {
//        System.out.println("Exception raised while adding to cart: " + cause.getMessage());
//        // You can return a default Cart object or perform custom error handling here.
//        return new Cart(); // Return an empty Cart as a fallback.
//    }

    default List<Cart> fallbackMethodGetCartItems(Throwable cause) {
        System.out.println("Exception raised while getting cart items: " + cause.getMessage());
        // You can return a default list of Cart objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default ResponseEntity<Cart> fallbackMethodAddByOne(long id, Cart cart, Throwable cause) {
        System.out.println("Exception raised while adding to cart by one: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.notFound().build(); // Return a 404 Not Found as a fallback.
    }

    default ResponseEntity<Cart> fallbackMethodLessByOne(long id, Cart cart, Throwable cause) {
        System.out.println("Exception raised while reducing cart by one: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.notFound().build(); // Return a 404 Not Found as a fallback.
    }

    default ResponseEntity<?> fallbackMethodDeleteCart(Long id, Throwable cause) {
        System.out.println("Exception raised while deleting cart: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.notFound().build(); // Return a 404 Not Found as a fallback.
    }

    default void fallbackMethodDeleteAllCart(Throwable cause) {
        System.out.println("Exception raised while deleting all cart items: " + cause.getMessage());
        // You can perform custom error handling here.
    }
}



