package com.foodDelivery.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
    
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public class Cart {

		private long id;
		private int quantity;
		private float price;
	   
		private Product product;
		
		
	}



