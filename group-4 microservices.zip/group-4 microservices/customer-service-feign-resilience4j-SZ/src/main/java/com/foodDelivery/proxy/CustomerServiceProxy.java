package com.foodDelivery.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.foodDelivery.entity.Customer;

import java.util.List;
import java.util.Map;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "customer-service")
public interface CustomerServiceProxy {

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodAddCustomer")
    @PostMapping("/api/customers")
    public Customer addCustomer(@RequestBody Customer customer);

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodVerifyLogin")
    @PostMapping("/api/customers/login")
    public ResponseEntity<Boolean> verifyLogin(@RequestBody Map<String, String> loginData);

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodGetAllCustomers")
    @GetMapping("/api/customers")
    public List<Customer> getAllCustomers();

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodSearchCustomer")
    @GetMapping("/api/customers/search/{keyword}")
    public List<Customer> searchCustomer(@PathVariable String keyword);

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodDeleteCustomer")
    @DeleteMapping("/api/customers/{email}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable String email);

    @Retry(name = "customer-service")
    @CircuitBreaker(name = "customer-service", fallbackMethod = "fallbackMethodGetCustomerByEmail")
    @GetMapping("/api/customers/{email}")
    public Customer getCustomerByEmail(@PathVariable String email);

    default Customer fallbackMethodAddCustomer(@RequestBody Customer customer, Throwable cause) {
        System.out.println("Exception raised while adding a customer: " + cause.getMessage());
        // You can return a default Customer object or perform custom error handling here.
        return new Customer(); // Return an empty Customer as a fallback.
    }

    default ResponseEntity<Boolean> fallbackMethodVerifyLogin(@RequestBody Map<String, String> loginData, Throwable cause) {
        System.out.println("Exception raised while verifying login: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
    }

    default List<Customer> fallbackMethodGetAllCustomers(Throwable cause) {
        System.out.println("Exception raised while getting all customers: " + cause.getMessage());
        // You can return a default list of Customer objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default List<Customer> fallbackMethodSearchCustomer(String keyword, Throwable cause) {
        System.out.println("Exception raised while searching for customers: " + cause.getMessage());
        // You can return a default list of Customer objects or perform custom error handling here.
        return List.of(); // Return an empty list as a fallback.
    }

    default ResponseEntity<Void> fallbackMethodDeleteCustomer(String email, Throwable cause) {
        System.out.println("Exception raised while deleting a customer: " + cause.getMessage());
        // You can return a default ResponseEntity or perform custom error handling here.
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    default Customer fallbackMethodGetCustomerByEmail(String email, Throwable cause) {
        System.out.println("Exception raised while getting a customer by email: " + cause.getMessage());
        // You can return a default Customer object or perform custom error handling here.
        return new Customer(); // Return an empty Customer as a fallback.
    }
}
